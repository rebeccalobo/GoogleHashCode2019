package Input;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Set;

import hashcode.Image;

public class Reader {
	private File name;
	private Kattio io;
	private int N;
	
	public Reader(File name) throws FileNotFoundException {
		this.name = name;
		
		//Reading input file
		io = new Kattio(new FileInputStream(name));
		N = io.getInt();
		
	}
	
	public int getSize() {
		return N;
	}
	
	public Image[] getImages() {
		Image[] images =  new Image[N];
	
		//Input loop of inner data
		for(int i = 0; i < N; i++) {
			char orientation = io.getWord().charAt(0); 
			int M = io.getInt();
			Set<String> tags = new HashSet<>();
			
		
			for(int j= 0; j < M; j++) {
				tags.add(io.getWord());
			}
			
			images[i] = new Image(orientation, M, tags, i);
			//System.out.println(orientation + " " + M + " " + tags.toString());
		}
		
		return images;
	}
}
