package hashcode;

import java.util.ArrayList;
import java.util.Set;

public class Slide {
    private ArrayList<Image> slide;
    private Set<String> slide_tags;

    public Slide(Image image){
    	this.slide = new ArrayList<>();
    	this.slide.add(image);
    	this.slide_tags = image.getTags();
    }
    
    public boolean checkOrientation(char orientation) {
    	if(slide.size() > 1) {
    		return false;
    	}
    	
    	//Check if V
    	for(Image image: slide) {
    		if(image.getOrientation() == 'V') {
    			return true;
    		}
    	}
    	
    	return false;
    }
    
    public void addImage(Image image) {
    	slide.add(image);
    	
    	slide_tags.addAll(image.getTags());
    }

    public Set<String> getSlideTags(){
        return this.slide_tags;
    }
    
    public int getNumTags() {
    	return this.slide_tags.size();
    }

    //
    public int getSlideSize(){
        return slide.size();
    }
    
    public int tagsInThisNotThat(Slide other){
        int count = 0;
        for(String tag : slide_tags){
            if(!other.getSlideTags().contains(tag)) {
            	count++;
            }
        }
        return count;
    }
    
    public int commonTag(Slide other) {
    	int count = 0;
    	for(String tag: slide_tags) {
    		if(other.getSlideTags().contains(tag)) {
    			count++;
    		}
    	}
    	
    	return count;
    }

    public String toString(){
        String output_str = "";
        for(Image image : slide){
            output_str += image.getImageNo() + " ";
        }

        return output_str;
    }


}
