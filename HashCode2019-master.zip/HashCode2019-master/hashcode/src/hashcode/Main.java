package hashcode;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import Input.Reader;

public class Main {

	public static void main(String[] args) throws IOException {
		
		Reader file = new Reader(new File("src/inputFiles/d_pet_pictures.txt"));
		
		Image[] image = file.getImages();
		
		BufferedWriter writer = new BufferedWriter(new FileWriter("Answer.txt", true));
	
		
		ArrayList<Slide> slides = new ArrayList<>();
		for(int i = 0; i < image.length; i++) {		
			
			if(image[i].getOrientation() == 'H') {
				slides.add(new Slide(image[i]));
			}
		}
		
		for(int i = 0; i < image.length; i++) {
			if(image[i].getOrientation() == 'V'){
				boolean Added = false;
				for(Slide slide: slides) {
					if(slide.checkOrientation('V') && slide.getSlideSize() < 2 && !Added) {
						slide.addImage(image[i]);
						Added = true;
					}
				}
				
				if(!Added) {
					slides.add(new Slide(image[i]));
				}
				
			}
		}
		
		
		orderSlidesBasedOnInterest(slides);
	
		writer.write(Integer.toString(slides.size()) + "\n");
		for(Slide slide: slides) {
			writer.append(slide.toString() + "\n");
		}
		
		writer.close();
	}
	
	private static int score(ArrayList<Slide> slides){
        int sum = 0;
        for(int i = 0;i < slides.size() - 1;i++){
            sum += Math.min(Math.min(slides.get(i).tagsInThisNotThat(slides.get(i + 1)), 
            							slides.get(i + 1).tagsInThisNotThat(slides.get(i))),
            								slides.get(i).commonTag(slides.get(i+1)));
        }
        return sum;
    }
	
	private static ArrayList<Integer> generateNeighbourStateEvals(ArrayList<Slide> slides){
        ArrayList<Integer> scores_after_swap = new ArrayList<>();
        for(int i = 0;i < slides.size();i++){
            Collections.swap(slides, i, (i + 1) % slides.size());
            scores_after_swap.add(score(slides));
            Collections.swap(slides, i, (i + 1) % slides.size());
        }
        return scores_after_swap;
    }
	
	private static int pickBestNeighbourStateEval(ArrayList<Integer> neighboursEvals){
        return Collections.max(neighboursEvals);
    }
	
	private static void applyOperationToMoveToLocalBestState(ArrayList<Integer> neighboursEvals, ArrayList<Slide> slides){
	        int best_swap = neighboursEvals.indexOf(Collections.max(neighboursEvals));
	        Collections.swap(slides, best_swap, (best_swap + 1) % slides.size());
	}
	 
	 public static void orderSlidesBasedOnInterest(ArrayList<Slide> slides){
	        int currentStateEval = score(slides);
	        ArrayList<Integer> neighboursEvals = generateNeighbourStateEvals(slides);
	        int localBestStateEval = pickBestNeighbourStateEval(neighboursEvals);

	        if (localBestStateEval <= currentStateEval){
	        	return;
	        }
	        else {
	        	applyOperationToMoveToLocalBestState(neighboursEvals, slides);
	        	orderSlidesBasedOnInterest(slides);
	        }
	    }
}
