package hashcode;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;


public class Image {
    private char orientation;
    private int no_of_tags;
    private Set<String> tags;
    private int image_no;


    public Image(char rotation, int n, Set<String> tags, int image_no){
        this.orientation = rotation;
        this.tags = tags;
        this.no_of_tags = n;
        this.image_no = image_no;
    }
    public char getOrientation(){
        return orientation;
    }
    public Set<String> getTags(){
        return tags;
    }
    
    public int getImageNo() {
    	return image_no;
    }
    
    public String toString() {
    	return orientation + " " + no_of_tags + " "+ tags.toString();
    }
}

