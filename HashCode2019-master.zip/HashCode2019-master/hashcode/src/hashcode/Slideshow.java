package hashcode;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

class Slideshow{
    private ArrayList<Slide> slideshow = new ArrayList<>();

    public void add(Slide slide){
        slideshow.add(slide);
    }

    private int score(){
        int sum = 0;
        for(int i = 0;i < slideshow.size();i++){
        	int total_tags = slideshow.get(i).getNumTags() + slideshow.get(i + 1).getNumTags();
            sum += Math.min(Math.min(slideshow.get(i).tagsInThisNotThat(slideshow.get(i + 1)), slideshow.get(i + 1).tagsInThisNotThat(slideshow.get(i))), total_tags - (slideshow.get(i + 1).tagsInThisNotThat(slideshow.get(i)) + slideshow.get(i).tagsInThisNotThat(slideshow.get(i + 1)) ) );
        }
        return sum;
    }

    private ArrayList<Integer> generateNeighbourStateEvals(){
        ArrayList<Integer> scores_after_swap = new ArrayList<>();
        for(int i = 0;i < slideshow.size();i++){
            Collections.swap(slideshow, i, (i + 1) % slideshow.size());
            scores_after_swap.add(this.score());
            Collections.swap(slideshow, i, (i + 1) % slideshow.size());
        }
        return scores_after_swap;
    }

    private int pickBestNeighbourStateEval(ArrayList<Integer> neighboursEvals){
        return Collections.max(neighboursEvals);
    }

    private void applyOperationToMoveToLocalBestState(ArrayList<Integer> neighboursEvals){
        int best_swap = neighboursEvals.indexOf(Collections.max(neighboursEvals));
        Collections.swap(slideshow, best_swap, (best_swap + 1) % slideshow.size());
    }

    public void orderSliedesBasedOnInterst(){
        int currentStateEval = this.score();
        ArrayList<Integer> neighboursEvals = generateNeighbourStateEvals();
        int localBestStateEval = this.pickBestNeighbourStateEval(neighboursEvals);

        if (localBestStateEval < currentStateEval){
        	currentStateEval();
        }
        else {
        	applyOperationToMoveToLocalBestState(neighboursEvals);
        	orderSliedesBasedOnInterst();
        }
    }

    private int currentStateEval(){
        return this.score();
    }
    public String toString(){
//<<<<<<< Updated upstream
        String output_str = this.slideshow.size() + "\n";
//=======
        output_str = this.slideshow.size() + "\n";
//>>>>>>> Stashed changes
        for(Slide slide : slideshow)
            output_str += slide.toString();

        return output_str;
    }
}